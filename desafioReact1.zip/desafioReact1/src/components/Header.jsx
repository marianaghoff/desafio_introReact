// Crear el componente Header.jsx que muestre el título “Adopta un perrito”.
import React from "react";

const Header = () => {
  return <h1>Adopta un perrito</h1>;
};

export default Header;
